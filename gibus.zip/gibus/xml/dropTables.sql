drop table gagnantfestival;
drop table grandefinale;
drop table groupe;
drop table jourfestival;
drop table festival;
drop table ville;
